PACKAGE A5

CONTENT?

Let denote
'+' a folder
'#' a source file/script 
"->" a file description
"FLAGS" feasible script options

+cpp
  #HW.cpp 
    -> print Hello World to STDOUT
  #WC.cpp 
    -> count total number of words and different words
    FLAGS
      -I (count words case-insensitive)
      -l (list word/count pairs)
  #OP.cpp 
    -> partition an even set of elements into pairs such that the total pair-costs are maximally low and each pair cost is below a given constraint  
    FLAGS
      -o (print optimal cost, instead of enumerating feasible pair sets) 

+java
  #DP.java
    -> find the path with maximum weight given an input of matrices containing NORTH-SOUTH and WEST-EAST (and DIAGONAL) weights
    FLAGS
      -t (print optimal path)
      -d (additionally process diagonal weights)

+py
  #RD.py
    -> generate a random string that approximatively preserves the letter frequencies of input string
    FLAGS
      -N _ (specify number of strings to generate, replace _ with an integer)
  #MS.py
    -> use FISHER-YATES shuffling to generate a new string that exactly preserves the letter frequencies of the input string
    FLAGS
      -N _ (specify number of strings to generate, replace _ with an integer)
  #KLS.py
    -> use K-LET-SHUFFLING to generate a new string that exactly preserves the K-LET frequencies of the input string
    FLAGS
      -N _ (specify number of strings to generate, replace _ with an integer)
      -k - (specify klet for KLetShuffling, replace _ with an integer)

COMPILE & RUN?

+cpp
  HOW to COMPILE?
    - Install the C++ compiler clang (https://clang.llvm.org/).
    - Install the package manage anaconda for your OS (https://docs.anaconda.com/anaconda/install/).
    - After installation execute below on your shell:
        > conda install -c statiskit clang

    - After installation navigate to +cpp and compile source code using
        > clang++ -Wall -Wextra -std=c++17 -O3 -pedantic-errors -fsanitize=address -fsanitize=undefined -fno-sanitize-recover=all *.cpp -o *
        
    , where you replace '*' with the name of the file.

    ALTERNATIVE:
      Install VisualStudioCode and the VSC extension C/C++ on your OS and use it to build the binaries.

  HOW to RUN?
     > ./* -options arg

     '*' is replaced by the name of the generated executable
     replace `-options´ with feasible flags
     replace `arg´ with the name of the input file

+java
  HOW to COMPILE?
    - Install JRE/JDK for your OS (https://www.java.com/en/download/help/download_options.html)
    - After installation execute on your shell:
        > javac *.java
     
      , where you replace * with the name of the file.
    
    HOW to RUN?
      > java * -options arg
      
      '*' is replaced by the name of the generated executable
      replace `-options´ with feasible flags
      replace `arg´ with the name of the input file

+py
  - Install python for your OS (https://www.python.org/downloads/)
  
  HOW to RUN?
    > python * -options arg

    '*' is replaced by the name of the generated executable
    replace `-options´ with feasible flags
    replace `arg´ with the name of the input file