Dear user,
this program provides the following tools:

S0
  -> print "Hello World" and content of input file to STDOUT
S1
  -> count total number of words and different words in input file
S2
  -> partition an even set of elements into pairs such that the total pair-costs are maximally low
S3 
  -> find the path with maximum weight given an input of matrices containing NORTH-SOUTH and WEST-EAST (and DIAGONAL) weights
S4
  -> generate a random string that approximatively preserves the base/aa frequencies of the input string
S5
  -> use FISHER-YATES shuffling to generate a new string that exactly preserves the base/aa frequencies of the input string
S6
  -> use K-LET-SHUFFLING to generate a new string that exactly preserves the K-LET frequencies of the input base/aa sequence


*You can interrupt the program at any point using ´crtl-C´.*

DEPENDENCIES:

- java JRE/JDK
- python 3
- clang++ compiler (only required if you want to run C++ src manually)