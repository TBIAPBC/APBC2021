COMPILE & RUN?

cpp source code
  HOW to COMPILE?
    - Install the C++ compiler clang (https://clang.llvm.org/).
    - Install the package manage anaconda for your OS (https://docs.anaconda.com/anaconda/install/).
    - After installation execute below on your shell:
        > conda install -c statiskit clang

    - After installation navigate to +cpp and compile source code using
        > clang++ -Wall -Wextra -std=c++17 -O3 -pedantic-errors -fsanitize=address -fsanitize=undefined -fno-sanitize-recover=all *.cpp -o *
        
    , where you replace '*' with the name of the file.

    ALTERNATIVE:
      Install VisualStudioCode and the VSC extension C/C++ on your OS and use it to build the binaries.

  HOW to RUN?
     > ./* -options arg

     '*' is replaced by the name of the generated executable
     replace `-options´ with feasible flags
     replace `arg´ with the name of the input file

java source code
  HOW to COMPILE?
    - Install JRE/JDK for your OS (https://www.java.com/en/download/help/download_options.html)
    - After installation execute on your shell:
        > javac *.java
     
      , where you replace * with the name of the file.
    
    HOW to RUN?
      > java * -options arg
      
      '*' is replaced by the name of the generated executable
      replace `-options´ with feasible flags
      replace `arg´ with the name of the input file

python script
  - Install python for your OS (https://www.python.org/downloads/)
  
  HOW to RUN?
    > python * -options arg

    '*' is replaced by the name of the generated executable
    replace `-options´ with feasible flags
    replace `arg´ with the name of the input file