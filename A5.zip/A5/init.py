import os
import sys
import subprocess

def welcome_msg():
    print("\n\n",open("txt/welcome.md",'r').read(),"\n\n")
    
def _input_(prompt):
    return input(prompt).replace(" ", "").split(",")
    
def select_tool():
    cpp_exe = ["S0","S1","S2"]
    java_exe = ["S3"]
    py_exe = ["S4","S5","S6"]
    while(True):
        tool = input("\nPlease select the tool you want to use (e.g. \"S0\"): ")
        print("\n")
        if tool in cpp_exe:
            return (tool, "cpp")
        if tool in java_exe:
            return (tool, "java")
        if tool in py_exe:
            return (tool, "py")
        print("ToolNotFound: please make sure you choose one of the tools listed above!")
        
def select_options(tool):
    prompt="Select either no or given options by typing in the corresponding comma-separated flags (afterwards hit `ENTER´):\n"
    if tool == "S1":
        print("-I: count words case-insensitive")
        print("-l: list word/count pairs")
        return _input_(prompt)
    if tool == "S2":
        print("-o: print optimal cost, instead of enumerating feasible pair sets:")
        return _input_(prompt)
    if tool == "S3":
        print("-t: print optimal path")
        print("-d: process diagonal weights in input file:")
        return _input_(prompt)
    if tool in ["S4", "S5", "S6"]:
        num_str="-N,"+input("Specify number of strings to generate (afterwards hit `ENTER´):\n")
        if tool == "S6":
            num_k="-k,"+input("Specify size of k-let for K-Let-Shuffling:\n")

def select_file(tool):
    see_example = input("Do you want to see an example input file for the chosen tool (y/n)? ")
    if see_example == "y" or see_example == "Y":
        print("\n\n")
        print(open("inputFiles/examples/"+tool+".in", 'r').read())
        print("\n\n")
    input("Hit `ENTER´ to continue")
    fileNotFound=True
    while(fileNotFound):
        input("Please place your input file into the folder `inputFiles´ … when done hit `ENTER´")
        filename=input("Now enter the filename: ")
        if not os.path.exists("inputFiles/"+filename):
            print("File not found, please try again!")
            continue
        fileNotFound=False   
    return ["inputFiles/"+filename]
            
def generate_cmd():
    tool, lang = select_tool()
    if lang == "cpp":
        return ["bins/"+tool]+select_options(tool)+select_file(tool)
    if lang == "java":
        return ["java"]+["bins/"+tool]+select_options(tool)+select_file(tool)
    if lang == "py":
        return ["python"]+["bins/"+tool+".py"]+select_options(tool)+select_file(tool)

if __name__ == "__main__":
    keep_running=True
    while(keep_running):
        welcome_msg()
        print_doc=input("\nPrint documentation on how to get dependencies/run src manually? (y/n)")
        if print_doc == "y" or print_doc == "Y":
            print(open("txt/doc.md", 'r').read())
        return_code = ["init",""]
        while(not return_code == ["", 0]):
            result = subprocess.run(generate_cmd(), capture_output=True)
            return_code = [bytes.decode(result.stderr), result.returncode]
            if not return_code[0] == "":
                print("STDERR:\n\n",return_code[0])
            if not bytes.decode(result.stdout) == "":
                print("STDOUT:\n\n",bytes.decode(result.stdout))
            if not return_code == ["", 0]:
                answer = input("Do you want to try again (y/n)? ")
                if answer == "n" or answer == "N":
                    break
        answer = input("Do you want to try another tool (y/n)? ")
        if answer == "n" or answer == "N":
            keep_running = False
    sys.exit(0)