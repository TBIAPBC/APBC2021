This Package contains all exercise programms to be usd as modules:
A0:
A1:
A2:
A3:
A4:

